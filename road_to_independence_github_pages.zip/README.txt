ROAD TO INDEPENDENCE — GITHUB PAGES

1. Create a free GitHub repository, e.g. road-to-independence.
2. Upload index.html to the repository root.
3. Settings > Pages > Build and deployment > Deploy from a branch.
4. Select main and /(root), then Save.
5. Wait for the Pages site link to appear. Share it with students. No student accounts required.

Game is standalone and works offline after download. Each group uses one browser/device; progress is saved only on that device and browser. Do not use private browsing for saved progress. No live shared leaderboard or central collection of student data.

All scenario decisions and movement are fictional teaching simulations. Real historical examples are explicitly distinguished.
